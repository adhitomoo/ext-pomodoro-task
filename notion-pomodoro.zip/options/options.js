import { getSettings, saveSettings } from "../utils/storage.js";
import { fetchDatabaseProperties, autoDetectProperties, getActiveStatusOptions, ensurePomodoroCountProperty } from "../lib/notion-api.js";
import { fetchClickUpTeams, fetchClickUpFolderLists } from "../lib/clickup-api.js";
import { THEMES, applyTheme } from "../utils/themes.js";

const $ = (id) => document.getElementById(id);

const CLICKUP_TEAM_ID = "90181891649";
const CLICKUP_FOLDER_ID = "90189840469";

const elements = {
  notionEnabled: $("notionEnabled"),
  clickupEnabled: $("clickupEnabled"),
  notionSection: $("notionSection"),
  clickupSection: $("clickupSection"),
  notionToken: $("notionToken"),
  notionDatabaseId: $("notionDatabaseId"),
  testConnection: $("testConnection"),
  connectionMessage: $("connectionMessage"),
  propertyMapping: $("propertyMapping"),
  pomodoroCountProperty: $("pomodoroCountProperty"),
  statusProperty: $("statusProperty"),
  doneStatusValue: $("doneStatusValue"),
  clickupToken: $("clickupToken"),
  testClickUp: $("testClickUp"),
  clickupMessage: $("clickupMessage"),
  clickupListField: $("clickupListField"),
  clickupListId: $("clickupListId"),
  clickupFilterField: $("clickupFilterField"),
  clickupFilterMe: $("clickupFilterMe"),
  workDuration: $("workDuration"),
  shortBreakDuration: $("shortBreakDuration"),
  longBreakDuration: $("longBreakDuration"),
  longBreakInterval: $("longBreakInterval"),
  soundEnabled: $("soundEnabled"),
  autoStartBreak: $("autoStartBreak"),
  autoStartWork: $("autoStartWork"),
  saveBtn: $("saveBtn"),
  saveMessage: $("saveMessage"),
  themeOptions: $("themeOptions"),
};

function showMessage(el, text, type) {
  el.textContent = text;
  el.className = `message message-${type}`;
  if (type === "success") {
    setTimeout(() => { el.textContent = ""; }, 3000);
  }
}

function updateSectionVisibility() {
  elements.notionSection.style.display = elements.notionEnabled.checked ? "block" : "none";
  elements.clickupSection.style.display = elements.clickupEnabled.checked ? "block" : "none";
}

elements.notionEnabled.addEventListener("change", updateSectionVisibility);
elements.clickupEnabled.addEventListener("change", updateSectionVisibility);

async function loadSettings() {
  const settings = await getSettings();

  elements.notionEnabled.checked = settings.notionEnabled;
  elements.clickupEnabled.checked = settings.clickupEnabled;
  updateSectionVisibility();

  elements.notionToken.value = settings.notionToken;
  elements.notionDatabaseId.value = settings.notionDatabaseId;
  elements.workDuration.value = settings.workDuration;
  elements.shortBreakDuration.value = settings.shortBreakDuration;
  elements.longBreakDuration.value = settings.longBreakDuration;
  elements.longBreakInterval.value = settings.longBreakInterval;
  elements.soundEnabled.checked = settings.soundEnabled;
  elements.autoStartBreak.checked = settings.autoStartBreak;
  elements.autoStartWork.checked = settings.autoStartWork;
  elements.pomodoroCountProperty.value = settings.pomodoroCountProperty;
  elements.statusProperty.value = settings.statusProperty;
  elements.doneStatusValue.value = settings.doneStatusValue;
  elements.clickupToken.value = settings.clickupToken;
  elements.clickupFilterMe.checked = settings.clickupFilterMe;

  applyTheme(settings.theme);
  updateThemeSelection(settings.theme);

  if (settings.notionEnabled && settings.notionToken && settings.notionDatabaseId) {
    await detectProperties(settings.notionToken, settings.notionDatabaseId);
  }

  if (settings.clickupEnabled && settings.clickupToken) {
    await loadClickUpLists(settings.clickupToken, settings.clickupListId);
  }
}

async function detectProperties(token, databaseId) {
  try {
    await ensurePomodoroCountProperty(token, databaseId);

    const properties = await fetchDatabaseProperties(token, databaseId);
    const detected = autoDetectProperties(properties);

    elements.pomodoroCountProperty.innerHTML = '<option value="">-- None (don\'t track count) --</option>';
    detected.number.forEach((name) => {
      const opt = document.createElement("option");
      opt.value = name;
      opt.textContent = name;
      elements.pomodoroCountProperty.appendChild(opt);
    });

    elements.statusProperty.innerHTML = '<option value="">-- None (don\'t update status) --</option>';
    detected.status.forEach((name) => {
      const opt = document.createElement("option");
      opt.value = name;
      opt.textContent = name;
      elements.statusProperty.appendChild(opt);
    });

    elements.propertyMapping.style.display = "block";

    const settings = await getSettings();
    elements.pomodoroCountProperty.value = settings.pomodoroCountProperty || "Pomodoro Count";
    if (settings.statusProperty) {
      elements.statusProperty.value = settings.statusProperty;
    }

    const activeStatusOpts = detected.status.length > 0
      ? getActiveStatusOptions(properties, detected.status[0])
      : [];

    await saveSettings({
      ...settings,
      notionToken: token,
      notionDatabaseId: databaseId,
      activeStatusOptions: activeStatusOpts,
      pomodoroCountProperty: settings.pomodoroCountProperty || "Pomodoro Count"
    });

    return detected;
  } catch (err) {
    showMessage(elements.connectionMessage, `Error: ${err.message}`, "error");
    return null;
  }
}

async function loadClickUpLists(token, selectedListId) {
  try {
    const lists = await fetchClickUpFolderLists(token, CLICKUP_FOLDER_ID);

    elements.clickupListId.innerHTML = '<option value="">-- Select a list --</option>';
    lists.forEach((list) => {
      const opt = document.createElement("option");
      opt.value = list.id;
      opt.textContent = list.name;
      elements.clickupListId.appendChild(opt);
    });

    if (selectedListId) {
      elements.clickupListId.value = selectedListId;
    }

    elements.clickupListField.style.display = "block";
    elements.clickupFilterField.style.display = "flex";
    return lists;
  } catch (err) {
    showMessage(elements.clickupMessage, `Error: ${err.message}`, "error");
    return null;
  }
}

function updateThemeSelection(themeId) {
  elements.themeOptions.querySelectorAll(".theme-swatch").forEach((el) => {
    el.classList.toggle("active", el.dataset.theme === themeId);
  });
}

elements.themeOptions.addEventListener("click", async (e) => {
  const swatch = e.target.closest(".theme-swatch");
  if (!swatch) return;

  const themeId = swatch.dataset.theme;
  applyTheme(themeId);
  updateThemeSelection(themeId);

  const settings = await getSettings();
  await saveSettings({ ...settings, theme: themeId });
});

elements.testConnection.addEventListener("click", async () => {
  const token = elements.notionToken.value.trim();
  const databaseId = elements.notionDatabaseId.value.trim();

  if (!token || !databaseId) {
    showMessage(elements.connectionMessage, "Please enter both token and database ID", "error");
    return;
  }

  elements.testConnection.disabled = true;
  elements.testConnection.textContent = "Testing...";

  const detected = await detectProperties(token, databaseId);

  elements.testConnection.disabled = false;
  elements.testConnection.textContent = "Test Connection";

  if (detected) {
    showMessage(elements.connectionMessage, "Connected! Properties detected.", "success");
  }
});

elements.testClickUp.addEventListener("click", async () => {
  const token = elements.clickupToken.value.trim();

  if (!token) {
    showMessage(elements.clickupMessage, "Please enter your API token", "error");
    return;
  }

  elements.testClickUp.disabled = true;
  elements.testClickUp.textContent = "Testing...";

  try {
    const teams = await fetchClickUpTeams(token);
    const lists = await loadClickUpLists(token, null);

    const settings = await getSettings();
    await saveSettings({ ...settings, clickupToken: token });

    if (teams && lists) {
      showMessage(elements.clickupMessage, `Connected! Found ${lists.length} lists in Avatar folder.`, "success");
    }
  } catch (err) {
    showMessage(elements.clickupMessage, `Error: ${err.message}`, "error");
  }

  elements.testClickUp.disabled = false;
  elements.testClickUp.textContent = "Test Connection";
});

elements.saveBtn.addEventListener("click", async () => {
  const notionEnabled = elements.notionEnabled.checked;
  const clickupEnabled = elements.clickupEnabled.checked;

  if (!notionEnabled && !clickupEnabled) {
    showMessage(elements.saveMessage, "Enable at least one task source", "error");
    return;
  }

  const settings = {
    notionEnabled,
    clickupEnabled,
    notionToken: elements.notionToken.value.trim(),
    notionDatabaseId: elements.notionDatabaseId.value.trim(),
    clickupToken: elements.clickupToken.value.trim(),
    clickupTeamId: CLICKUP_TEAM_ID,
    clickupListId: elements.clickupListId.value,
    clickupFilterMe: elements.clickupFilterMe.checked,
    workDuration: parseInt(elements.workDuration.value) || 25,
    shortBreakDuration: parseInt(elements.shortBreakDuration.value) || 5,
    longBreakDuration: parseInt(elements.longBreakDuration.value) || 15,
    longBreakInterval: parseInt(elements.longBreakInterval.value) || 4,
    soundEnabled: elements.soundEnabled.checked,
    autoStartBreak: elements.autoStartBreak.checked,
    autoStartWork: elements.autoStartWork.checked,
    pomodoroCountProperty: elements.pomodoroCountProperty.value,
    statusProperty: elements.statusProperty.value,
    doneStatusValue: elements.doneStatusValue.value.trim() || "Done",
    theme: document.querySelector(".theme-swatch.active")?.dataset.theme || "ocean"
  };

  await saveSettings(settings);
  showMessage(elements.saveMessage, "Settings saved!", "success");
});

loadSettings();
